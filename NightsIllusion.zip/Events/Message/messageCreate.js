// const client = require("../../Structures/index"); // make sure this path is correct
// const Levels = require("discord-xp");
// const { Database } = require('../../Structures/config.json');
// Levels.setURL(Database);

// client.on("messageCreate", async (message) => {
//   if(message.author.bot || !message.guildId) return;

//   const channel = client.channels.cache.get('921070301926809731');
//   const xp = Math.floor(Math.random() * 9) + 1;
//   const hasLeveledUp = await Levels.appendXp(message.author.id, message.guildId, xp)
//   if(hasLeveledUp) {
//     const LVL5RoleID = '921071187277271082'
//     const LVL10RoleID = '921071250451861564'
//     const LVL15RoleID = '921071277794553908'
//     const LVL25RoleID = '921071308765278228'
//     const LVL50RoleID = '921071340935577711'
//     const LVL100RoleID = '921071373919604846'

//     const user = await Levels.fetch(message.author.id, message.guildId);
//     channel.send(`${message.author}, congratulations! You have leveled up to **${user.level}**. :tada:`)

//     if (user.level == 5) {
//         message.member.roles.add(LVL5RoleID);
//     } else if (user.level == 10) {
//         message.member.roles.add(LVL10RoleID);
//         message.member.roles.remove(LVL5RoleID);
//     } else if (user.level == 15) {
//         message.member.roles.add(LVL15RoleID);
//         message.member.roles.remove(LVL10RoleID);
//     } else if (user.level == 25) {
//         message.member.roles.add(LVL25RoleID);
//         message.member.roles.remove(LVL15RoleID);
//     } else if (user.level == 50) {
//         message.member.roles.add(LVL50RoleID);
//         message.member.roles.remove(LVL25RoleID);
//     } else if (user.level == 100) {
//         message.member.roles.add(LVL100RoleID);
//         message.member.roles.remove(LVL50RoleID);
//     }
//   }
// })
