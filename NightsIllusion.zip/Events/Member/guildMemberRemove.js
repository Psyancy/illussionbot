// const { MessageEmbed, WebhookClient, GuildMember  } = require("discord.js");

// module.exports = {
//     name: "guildMemberRemove",
//     /**
//      *
//      * @param {GuildMember} member
//      */
//     execute(member) {
//         const { user, guild } = member;

//         const Leaver = new WebhookClient({
//             id: "921069986074746881",
//             token: "xqkeojWcqa8AoUg9Y0hszo4uB7iY12oIg3P6p_lVMlU07OGJnZReZaNXswKLSHfyqwyf"
//         });

//         const Leave = new MessageEmbed()
//         .setColor("RED")
//         .setAuthor(user.tag, user.avatarURL({dynamic: true, size: 512}))
//         .setThumbnail(user.avatarURL({dynamic: true, size: 512}))
//         .setDescription(`
//         ${member} has left **${guild.name}**'s Discord Server!\n
//         Joined: <t:${parseInt(member.joinedTimestamp / 1000)}:R>\n
//         Latest Member Count: **${guild.memberCount}**`)

//         Leaver.send({embeds: [Leave]})
//     }
// }
