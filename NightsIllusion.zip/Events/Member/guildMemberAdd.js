const { MessageEmbed, WebhookClient, GuildMember } = require("discord.js");

module.exports = {
  name: "guildMemberAdd",
  /**
   *
   * @param {GuildMember} member
   */
  execute(member) {
    const { user, guild } = member;
    const currentDate = new Date();

    member.roles.add("830762357662679064");
    const Welcomer = new WebhookClient({
      id: "1013058690691108984",
      token:
        "vtIv6Hy9HoL27HQRjAZoFPNVVQOJC8t0-LO4vRvhuKEOc_F09CrjHcKITQ5kyZIKvsU0",
    });

    const Welcome = new MessageEmbed()
      .setColor("#72092c")
      .setAuthor(user.tag, user.avatarURL({ dynamic: true, size: 512 }))
      .setThumbnail(user.avatarURL({ dynamic: true, size: 512 }))
      .setDescription(
        `
        Welcome ${member} to the **${guild.name}**'s Discord Server!\n
        Make sure to check the channels tagged bellow to get involved!\n
        Account Created: <t:${parseInt(user.createdTimestamp / 1000)}:R>\n
        Latest Member Count: **${guild.memberCount}**`
      )
      .addFields([
        {
          name: "📑Rules",
          value: "<#1013040286613639178>",
          inline: true,
        },
        {
          name: "📢Announcements",
          value: "<#1013040636913524776>",
          inline: true,
        },
        {
          name: "✨Get Roles",
          value: "<#1013039341792141403>",
          inline: true,
        },
      ])
      .setFooter(
        `${
          user.tag
        } • ${currentDate.toDateString()} - ${currentDate.toLocaleTimeString()}`
      );

    Welcomer.send({ embeds: [Welcome] });
  },
};
