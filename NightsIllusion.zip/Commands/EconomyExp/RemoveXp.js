const { CommandInteraction } = require("discord.js");
const Levels = require("discord-xp");
Database = require("../../Structures/config.json")
OwnerID = require("../../Structures/config.json")
Levels.setURL(Database);

module.exports = {
    name: "removexp",
    description: "Removes the xp of a user.",
    options: [{
        name: "user",
        description: "The User",
        type: "USER",
        required: true
    }, {
        name: "amount",
        description: "Amount of XP.",
        type: "NUMBER",
        required: true
    }],

    /**
     *
     * @param {CommandInteraction} interaction 
     */

    async execute(interaction) {
        if (interaction.user.id == "307881984649199616" && "853430267363328020") {
            const User = interaction.options.getUser("user");
            const XPAmount = interaction.options.getNumber("amount");
            Levels.subtractXp(User.id, interaction.guildId, XPAmount);
    
            interaction.reply({
                content: `✅ Removed ${XPAmount} xp from user ${User} successfully.`,
                ephemeral: true
            })
        } else {
            interaction.reply({
                content: "Your not my maker. Access Denied",
                ephemeral: true
            })
        }
    } 
}