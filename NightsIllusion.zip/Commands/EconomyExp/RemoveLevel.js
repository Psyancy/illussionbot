const { CommandInteraction } = require("discord.js");
const Levels = require("discord-xp");
Database = require("../../Structures/config.json")
OwnerID = require("../../Structures/config.json")
Levels.setURL(Database);

module.exports = {
    name: "removelevel",
    description: "Removes the level of a user.",
    options: [{
        name: "user",
        description: "The User",
        type: "USER",
        required: true
    }, {
        name: "amount",
        description: "Amount of Level.",
        type: "NUMBER",
        required: true
    }],

    /**
     *
     * @param {CommandInteraction} interaction 
     */

    async execute(interaction) {
        if (interaction.user.id == "307881984649199616" && "853430267363328020") {
            const User = interaction.options.getUser("user");
            const LVLAmount = interaction.options.getNumber("amount");
            Levels.subtractLevel(User.id, interaction.guildId, LVLAmount);
    
            interaction.reply({
                content: `✅ Removed ${LVLAmount} level(s) from user ${User} successfully.`,
                ephemeral: true
            })
        } else {
            interaction.reply({
                content: "Your not my maker. Access Denied",
                ephemeral: true
            })
        }
    } 
}