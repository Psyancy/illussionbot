const { Client, CommandInteraction, MessageEmbed } = require("discord.js");

module.exports = {
    name: "ban",
    description: "Bans the target member.",
    permission: "BAN_MEMBERS",
    options: [
        {
            name: "target",
            description: "Select a target to ban.",
            type: "USER",
            required: true
        },
        {
            name: "reason",
            description: "Provide a reason for this ban.",
            type: "STRING",
            required: true
        },
        {
            name: "messages",
            description: "Choose one of the choices.",
            type: "STRING",
            required: true,
            choices: [
                {
                    name: "Don't delete any.",
                    value: "0"
                },
                {
                    name: "Previous 7 days.",
                    value: "7"
                }
            ]
        },
    ],
    /**
     * @param {CommandInteraction} interaction 
     */
    execute(interaction) {
        const Target = interaction.options.getMember('target');

        if (Target.id === interaction.member.id)
        return interaction.reply({embeds: [new MessageEmbed().setColor("RED").setDescription(`⛔ You cannot ban yourself.`)]})

        if (Target.permissions.has('ADMINISTRATOR'))
        return interaction.reply({embeds: [new MessageEmbed().setColor("RED").setDescription(`⛔ You cannot ban an Administrator.`)]})

        const Reason = interaction.options.getString('reason');

        if (Reason.length > 512)
        return interaction.follreplyowUp({embeds: [new MessageEmbed().setColor("RED").setDescription(`⛔ The reason cannot exceed 512 characters.`)]})

        const Amount = interaction.options.getString('messages')

        Target.ban({ days: Amount, reason: Reason})

        interaction.reply({embeds: [
            new MessageEmbed()
            .setColor("GREEN")
            .setTimestamp()
            .setDescription(`✅ **${Target.user.username}** has been banned.`)
            .addFields({
				name: "Reason For ban:",
				value: Reason
			})
        ]})
    }
}