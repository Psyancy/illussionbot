const { CommandInteraction, MessageEmbed, MessageActionRow, MessageButton, Client } = require("discord.js");

module.exports = {
    name: "invite",
    description: "Invite me to your server!",
    
    
    /**
     * @param {Client} client
     * @param {CommandInteraction} interaction 
     */
    async execute(interaction, client) {
      
        const Invite = new MessageEmbed()
        .setTitle("Invite Me!")
        .setDescription("I'm a cool Discord Bot, ain't I? Use the buttons below to invite me to your server or join our support server!\n\nStay Safe 👋")
        .setColor("#72092c")
        .setThumbnail(client.user.displayAvatarURL())

        const cButtons = new MessageActionRow();
        cButtons.addComponents(
            new MessageButton().setURL("https://discord.gg").setLabel("Invite Me").setStyle("LINK"),
            new MessageButton().setURL("https://discord.gg").setLabel("Support Server").setStyle("LINK"),
        );

        return interaction.reply({embeds: [Invite], components: [cButtons]})
        
    }
  };