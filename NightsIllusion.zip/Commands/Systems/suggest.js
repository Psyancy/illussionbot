const { CommandInteraction, MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const DB = require("../../Structures/Schemas/SuggestDB");

module.exports = {
    name: "suggest",
    description: "Make a suggestion for Chilling Smite.",
    options: [
        {
            name: "type",
            description: "Select the type of the suggestion",
            type: "STRING",
            required: true,
            choices: [
                {name: "Command", value: "Command"},
                {name: "Game Bot", value: "Game Bot"},
                {name: "Role", value: "Role"},
                {name: "Other", value: "Other"}
            ]
        },
        {
            name: "suggestion",
            description: "Describe the functionality of the suggestion.",
            type: "STRING",
            required: true
        },
    ],
    /**
     * @param {CommandInteraction} interaction 
     */
    async execute(interaction) {
        const { options, guildId, member, user } = interaction;

        const cType = options.getString("type");
        const cSuggestion = options.getString("suggestion");

        const Embed = new MessageEmbed()
        .setColor("NAVY")
        .setAuthor(user.tag, user.displayAvatarURL({dynamic: true}))
        .addFields(
            {name: "Suggestion:", value: cSuggestion, inline: false},
            {name: "Type:", value: cType, inline: true},
            {name: "Status:", value: "Pending", inline: true},
        )

        const cButtons = new MessageActionRow();
        cButtons.addComponents(
            new MessageButton().setCustomId("suggest-accept").setLabel("✅ Accept").setStyle("PRIMARY"),
            new MessageButton().setCustomId("suggest-decline").setLabel("⛔ Decline").setStyle("SECONDARY"),
        );

        try {
            await interaction.reply({embeds: [Embed], components: [cButtons], fetchReply: true}).then(async (m) => {
                await DB.create({GuildID: guildId, MessageID: m.id, Details: [
                    {   
                        MemberID: member.id,
                        Type: cType,
                        Suggestion: cSuggestion
                    }
                ]}).catch((err) => console.log(err));
                m.react("<:Approved:916706006535389184>👍")
                m.react("<:Denied:916706018380120156>👎")
            })
        } catch(err) {
            console.log(err)
        }
    }
}